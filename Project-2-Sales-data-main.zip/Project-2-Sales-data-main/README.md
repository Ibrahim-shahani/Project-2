# Project-2-Sales-data
"Project 2: Excel-based analysis of sales data, unveiling actionable insights to optimize performance and drive strategic decisions."
